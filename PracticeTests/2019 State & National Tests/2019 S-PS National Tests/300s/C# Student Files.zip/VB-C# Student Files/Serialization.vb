Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Xml.Serialization

Namespace player_inventory
    Public Class Serialization
        Public Shared Sub Serialize(Of T)(ByVal value As T, ByVal path As String)
            Dim serializer As XmlSerializer = New XmlSerializer(GetType(T))
            Dim writer As TextWriter = New StreamWriter(path)
            serializer.Serialize(writer, value)
            writer.Close()
        End Sub

        Public Shared Function Deserialize(Of T)(ByVal path As String) As T
            Dim deserializer As XmlSerializer = New XmlSerializer(GetType(T))
            Dim reader As TextReader = New StreamReader(path)
            Dim obj As Object = deserializer.Deserialize(reader)
            reader.Close()
            Return CType(obj, T)
        End Function
    End Class
End Namespace